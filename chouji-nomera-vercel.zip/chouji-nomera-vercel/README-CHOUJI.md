# Backend Nomera untuk CHOUJI STOCK (Vercel + Supabase)

Paket ini mengadaptasi starter Nomera yang semula memakai Express + MySQL/MariaDB menjadi Vercel Functions + Supabase. File website `index.html` dan `admin.html` tidak perlu diubah untuk memasang backend ini.

## Isi folder

- `api/nomera-catalog.js` — katalog layanan.
- `api/nomera-products.js` — paket/negara untuk serviceId.
- `api/nomera-quote.js` — quote dan cek `available === true`.
- `api/nomera-create-order.js` — create order dengan idempotency key dan quote ulang di server.
- `api/nomera-my-order.js` — snapshot order.
- `api/nomera-check-order.js` — sinkron status ke provider.
- `api/nomera-cancel-order.js` — cek izin cancel sebelum request.
- `api/nomera-resend-order.js` — hanya resend saat `canResend === true`.
- `api/nomera-webhook.js` — verifikasi HMAC atas raw body dan simpan event secara durable.
- `supabase-nomera-schema.sql` — tabel tambahan; tidak mengubah tabel produk/pengaturan.

## Penting sebelum dipasang

1. Folder `api` harus berada sejajar dengan `index.html` dan `admin.html` di root project Vercel.
2. Gabungkan file `api` dari paket ini ke folder `api` project CHOUJI STOCK. Jangan menimpa file website.
3. Tambahkan dependency `@supabase/supabase-js` ke `package.json` root project (jika belum ada). Jangan mengganti package.json lama secara membabi buta; gabungkan dependency-nya.
4. Jalankan `supabase-nomera-schema.sql` di Supabase SQL Editor. Tabel yang dibuat hanya `nomera_orders` dan `nomera_webhook_events`.
5. Tambahkan Environment Variables di Vercel: `NOMERA_API_KEY`, `NOMERA_BASE_URL`, `NOMERA_WEBHOOK_SECRET`, `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `SUPABASE_SECRET_KEY`. Semua secret hanya di Vercel, jangan di HTML.
6. Deploy melalui alur GitHub/Vercel yang biasa kamu pakai setelah memeriksa perubahan.
7. Callback Nomera: `https://DOMAIN-WEBSITE/api/nomera-webhook`.

## Catatan autentikasi pelanggan — wajib diperhatikan

Endpoint create, my-order, check, cancel, dan resend mewajibkan Supabase Auth Bearer access token. Ini sengaja untuk mencegah orang lain membaca OTP atau membatalkan order milik pelanggan lain. Dari pemeriksaan file website yang tersedia sebelumnya, login Supabase Auth admin terlihat, tetapi login pelanggan belum terkonfirmasi. Karena itu, backend ini belum boleh dihubungkan ke tombol beli/live checkout sampai alur identitas pelanggan dipastikan. Jangan menghapus pemeriksaan auth untuk membuatnya “jalan”.

Jika website belum punya login pelanggan, perlu disepakati cara aman mengikat invoice ke pelanggan (misalnya token akses transaksi acak yang disimpan hash-nya di database), sebelum membuka endpoint status/OTP.

## Bentuk request

- `GET /api/nomera-catalog`
- `GET /api/nomera-products?serviceId=...`
- `GET /api/nomera-quote?serviceId=...&countryId=...&offerKey=...`
- `POST /api/nomera-create-order` JSON `{ "serviceId":"...", "countryId":"...", "offerKey":"...", "idempotencyKey":"unik-8-128-karakter" }` + header `Authorization: Bearer SUPABASE_ACCESS_TOKEN`
- `GET /api/nomera-my-order?orderId=...` + auth
- `POST /api/nomera-check-order` JSON `{ "orderId":"..." }` + auth
- `POST /api/nomera-cancel-order` JSON `{ "orderId":"..." }` + auth
- `POST /api/nomera-resend-order` JSON `{ "orderId":"..." }` + auth

Catalog/products/quote hanya meneruskan informasi layanan/paket. Order dan OTP memerlukan auth. Endpoint quote tidak melakukan pembelian.

## Idempotency

Satu `idempotencyKey` unik untuk satu checkout. Jika timeout atau status create belum pasti, ulangi dengan key dan parameter yang sama. Jangan membuat key baru untuk percobaan ulang transaksi yang sama. Provider Nomera tetap menjadi otoritas idempotency.

## Webhook

Webhook memverifikasi `X-Nomera-Signature` sebagai `sha256=HEX` menggunakan HMAC-SHA256 atas raw request body dan perbandingan timing-safe. Event ID menjadi primary key untuk deduplikasi. Event disimpan sebelum HTTP 200. Paket ini menyimpan inbox webhook; pemrosesan event untuk memperbarui tampilan order/invoice belum diaktifkan karena skema transaksi toko dan relasi invoice belum diperiksa.

## Batas integrasi saat ini

- Tidak mengintegrasikan deposit, saldo pelanggan, QRIS, refund otomatis website, atau riwayat transaksi lama.
- Tidak mengubah `index.html`, `admin.html`, tabel `produk`, atau `pengaturan`.
- Belum menampilkan OTP di frontend sampai autentikasi pelanggan dan relasi invoice selesai dipastikan.
- Uji katalog/quote terlebih dahulu; jangan melakukan create order nyata sebelum endpoint dan autentikasi selesai diverifikasi.
